// Solving_Sudoku.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
#include"sudoku.h"
#include "sudokuFitness.h"
using namespace std;
int main()
{
    Sudoku s1;
    cin >> s1;
    cout << s1;
}
