#pragma once
#include <iostream>
using namespace std;
class Population
{
public:
	virtual void cull() = 0;
};

